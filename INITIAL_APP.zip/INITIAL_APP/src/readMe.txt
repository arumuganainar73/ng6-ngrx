
Prerequisites :

Node 8.11.3 to create angular 6 project using angular cli 

To install the Angular CLI:  ( 6.0.0 and above – preferably stable )
npm install -g @angular/cli


 

Generating and serving an Angular project via a development server Create and run a new project:
ng new my-project
	C:\Users\POC > ng new ng-ngrx
cd my-project
	C:\Users\POC\ng-ngrx> 
ng serve
	   C:\Users\POC\ng-ngrx>ng serve
 

npm install @angular/cdk

npm install @angular/material

npm install angular-in-memory-web-api --save-dev


added below code inside head tag: 
<head>
…
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">
…
</head>








